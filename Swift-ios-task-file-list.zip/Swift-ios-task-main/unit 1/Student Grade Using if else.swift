var mark: Int = 85

if mark >= 90 {
    print("Grade A")
} else if mark >= 80 {
    print("Grade B")
} else if mark >= 70 {
    print("Grade C")
} else if mark >= 60 {
    print("Grade D")
} else {
    print("Grade F")
}
